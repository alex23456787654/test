# <Nom du personnage>

**Espèce** <…> · **Classe** <…> niveau <n> · **Historique** <…> · **Alignement** <…>
**Concept** : <une phrase, avec le problème non résolu>

## Caractéristiques
| For | Dex | Con | Int | Sag | Cha |
|---|---|---|---|---|---|
| 00 (+0) | 00 (+0) | 00 (+0) | 00 (+0) | 00 (+0) | 00 (+0) |

**Bonus de maîtrise** +0 · **Perception passive** 00
**Sauvegardes maîtrisées** : <…>
**Compétences maîtrisées** : <…>

## Combat
- **PV** 00 / 00 · **PV temporaires** 0 · **Dés de vie** 0d0 restants
- **Inspiration** : ☐ <accordée pour un argument imprévu qui recadre la scène — voir
  `references/arbitrage-social.md` ; noter pourquoi elle a été donnée>
- **CA** 00 · **Initiative** +0 · **Vitesse** 0 m
- **Sauvegardes contre la mort** : succès ☐☐☐ · échecs ☐☐☐
- **Attaques** : <arme — bonus, dégâts, portée, propriétés>

## Aptitudes
<Traits d'espèce, aptitudes de classe et de sous-classe, dons. Note celles qui ont un
usage limité avec leur compteur : « Second souffle 1/1, récupère sur repos court ».>

## Magie
- **Caractéristique** <…> · **DD de sauvegarde** 00 · **Attaque de sort** +0
- **Emplacements** : niv.1 ☐☐ · niv.2 ☐☐ · <…>
- **Concentration en cours** : <aucune>
- **Sorts préparés / connus** : <…>

## Équipement
| Objet | Qté | Note |
|---|---|---|
| | | |

**Bourse** : <po / pa / pc> · **Charge** : <si la règle est appliquée>

## Liens et notes
- **Lié à** : <personne, lieu, dette, serment>
- **Ce que le personnage sait** : <informations acquises en jeu>
- **Ce qu'il croit à tort** : <utile : le monde peut le détromper>
- **Cicatrices** : <blessures, pertes, changements depuis le début>
