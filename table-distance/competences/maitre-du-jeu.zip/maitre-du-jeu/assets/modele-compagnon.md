# <Nom> — compagnon

**Rôle** : <son domaine de compétence, en trois mots>
**Veut** : <ce qui le fait agir>
**Refuse** : <sa ligne rouge à lui — aucun jet ne la franchit>
**Tension avec <le joueur>** : <celle qui n'a pas encore éclaté>
**Attitude** (−3 à +3) : <n>

## Chiffres (le minimum)

- **CA** 00 · **PV** 00 / 00 · **Initiative** +0
- **Attaque** : <nom — bonus, dégâts>
- **Spécialité** : <+4 dans son domaine, +0 ailleurs>
- **Base** : <bloc de référence : `regles.py bloc <nom>`, et l'écart s'il y en a un>

## Trajectoire

- **Attaches antérieures** : <d'où il vient — elles restent vivantes>
- **Ce que le joueur lui a promis** : <mot pour mot : les promesses sont des dettes>
- **Ce qu'il a fait d'important** : <une ligne par fait, avec la session>
