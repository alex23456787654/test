# <Nom> — fiche d'âme

> MJ uniquement · `mj/pnj/`. Ne contient **que ce que ce PNJ sait**. C'est ce que reçoit
> l'agent qui le joue (`references/agents-pnj.md`). Mise à jour après chaque scène où il paraît.

**Qui** : <espèce, rôle, âge, une ligne>
**Ce qui se voit** : <la particularité forte — une seule>

## Moteur
- **Veut** : <son but, maintenant>
- **Craint** : <ce qui le ferait reculer>
- **Refuse** : <sa ligne rouge — aucun jet ne la franchit>

## Ce qu'il sait
- <fait> *(appris : séance n, comment)*

## Ce qu'il ignore ou croit à tort
- <…>

## Ce qu'il cache
- <ce qu'il sait et ne dira pas, et à quelle condition il le dirait>

## Voix
<registre, longueur de phrase, tic>
> — <réplique exemple>
> — <réplique exemple>

## Attitude envers les personnages joueurs
| Personnage | −3 à +3 | Pourquoi |
|---|---|---|
| | | |

## Prochains mouvements *(tour du monde du <date>)*
1. <…>
2. <…>
