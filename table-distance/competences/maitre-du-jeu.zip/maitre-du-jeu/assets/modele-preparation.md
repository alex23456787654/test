# Préparation de séance — <campagne> · MAÎTRE DU JEU UNIQUEMENT

> Jamais affiché. Réécrit avant chaque séance, jamais retouché en cours de scène. Une
> préparation remplacée part dans `mj/archives/`.

## Séance <n>

### 0. Hors jeu, à trancher d'abord
- [ ] <XP de la séance précédente, vérité manquante à écrire, point de canon ouvert>

### 1. Tour du monde
<Agents lancés (ou fait à la main), ce qui a été retenu, ce qui a été écarté et pourquoi.>

### 2. Agenda — ce que chacun fait s'il n'est pas contrarié
| Qui | 1ᵉʳ mouvement | 2ᵉ | 3ᵉ |
|---|---|---|---|
| | | | |

### 3. La bascule
<L'événement qui change la donne, au plus tard aux deux tiers de la séance.>

### 4. L'ouverture
<Le « Précédemment » (ce qu'il faut rappeler), le « Pendant ce temps » (ce que le monde a fait hors
champ, ou une coupe sur un personnage resté ailleurs — faits publics seulement), puis la première
image et le coup du monde qui l'accompagne, et le personnage à qui l'on rend la main.>

### 5. Scènes probables, indices à placer
| Scène | Question | Pression | Indice ou révélation |
|---|---|---|---|
| | | | |

### 6. Rencontres prêtes
<Budget, blocs (`regles.py bloc`), terrain, objectif autre que tuer, porte de sortie.>

### 7. Tables d'aléa
<Complications (d6), rumeurs (d6), rencontres de route (d6) — propres au lieu.>
