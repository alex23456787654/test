# État — <campagne>

> **Où on en est, maintenant — et rien d'autre.** Une page, réécrite à chaque fin de scène.
> Le passé va dans `histoire.md`, le cadre dans `table.md`, les règles maison dans
> `arbitrages.md`, les secrets dans `mj/`. Un état remplacé part dans `archives/`.
>
> **Dossier** : <chemin absolu — l'ancre qui évite qu'une session ailleurs recrée la campagne>

## Arrêt sur image
<Lieu, heure en jeu, ce qui presse. Position de chacun, une ligne par personnage. Comptes à
rebours restants. La dernière phrase du MJ, au mot près.>

## Ressources
| | PV | Sorts / capacités | Bourse | Notes |
|---|---|---|---|---|
| | | | | |

## XP ou progression
<Compteur de groupe, palier suivant, ce qui reste à attribuer.>

## Horloges
| Menace | État | Ce qui la fait avancer |
|---|---|---|
| | | |

## Ce que certains savent seuls
- <personnage> : <…>

## PNJ et factions
| Qui | Où, quoi | Attitude (−3 à +3) |
|---|---|---|
| | | |

## Fils ouverts
<Une ligne, séparés par des points médians.>

## Avant de reprendre
<Renvoi à `mj/preparation.md`.>
