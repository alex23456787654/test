# La table — <campagne>

> Comment on joue à cette table. Public. Lu à chaque ouverture de séance, avant `etat.md`.

## Le cadre
- **Système** : <SRD 5.1 ; écarts admis, renvoyés à `arbitrages.md`>
- **Ton** : <…> · **Mortalité** : <…>
- **Lignes rouges et limites** : <…>
- **Progression** : <XP / chapitres ; où vit le compteur>

## Les joueurs
| Joueur | Personnage | Espèce · classe | Historique |
|---|---|---|---|
| | | | |

## Comment se déroule une séance
<Écran partagé lu à voix haute ? Chacun écrit ? Solo ? Qui joue à distance, par la page de
table ? Comment arrivent les déclarations, comment passe une information réservée à un seul
joueur, qui lance les dés.>

## Mener cette table
<Ce que le MJ doit surveiller ici : projecteur, prises personnelles de chaque personnage,
pentes observées lors des séances passées.>

## La palette
<Matières, sons, odeurs, images récurrentes ; ce qui est rare et fort ; le registre.>

## Les voix des PNJ
| PNJ | Comment il parle |
|---|---|
| | |
