#!/usr/bin/env python3
"""Lanceur de dés pour la compétence maitre-du-jeu.

Un modèle de langage ne sait pas produire de hasard : il produit ce qui « sonne
juste », ce qui biaise systématiquement la partie. Ce script tire de vrais
nombres aléatoires (module `secrets`), affiche le détail de chaque dé et peut
consigner le jet dans un journal horodaté que le joueur peut relire.

Notation acceptée (insensible à la casse, espaces ignorés) :
    1d20+5          un d20 plus 5
    2d6+1d4-1       plusieurs groupes
    4d6kh3          garder les 3 meilleurs (keep highest)
    2d20kl1         garder le plus bas (keep lowest)
    d100            1 est implicite

Exemples :
    python3 des.py 1d20+7 --etiquette "Attaque à l'épée longue"
    python3 des.py 1d20+3 --avantage --etiquette "Perception" --secret
    python3 des.py --stats
    python3 des.py 8d6 --etiquette "Boule de feu" --journal campagnes/orage/jets.log
"""

import argparse
import datetime
import re
import secrets
import sys

GROUPE = re.compile(r"^(\d*)d(\d+)(k[hl]\d+)?$", re.IGNORECASE)


def lancer(faces: int) -> int:
    return secrets.randbelow(faces) + 1


def evaluer(expression: str):
    """Retourne (total, detail_lisible). Lève ValueError si la notation est fausse."""
    expr = expression.replace(" ", "").lower()
    if not expr:
        raise ValueError("expression vide")
    # découpe en termes signés sans perdre les signes
    termes = re.findall(r"[+-]?[^+-]+", expr)
    total = 0
    morceaux = []
    for terme in termes:
        signe = -1 if terme.startswith("-") else 1
        corps = terme.lstrip("+-")
        if corps.isdigit():
            valeur = int(corps)
            total += signe * valeur
            morceaux.append(f"{'+' if signe > 0 else '-'}{valeur}")
            continue
        m = GROUPE.match(corps)
        if not m:
            raise ValueError(f"terme incompréhensible : {terme!r}")
        nombre = int(m.group(1) or 1)
        faces = int(m.group(2))
        garde = m.group(3)
        if nombre < 1 or nombre > 200 or faces < 2 or faces > 1000:
            raise ValueError(f"terme hors limites : {terme!r}")
        jets = [lancer(faces) for _ in range(nombre)]
        retenus = list(jets)
        if garde:
            sens, combien = garde[1], int(garde[2:])
            combien = max(1, min(combien, nombre))
            tries = sorted(jets, reverse=(sens == "h"))
            retenus = tries[:combien]
        somme = sum(retenus)
        total += signe * somme
        if garde:
            detail = f"{nombre}d{faces}{garde} [{', '.join(map(str, jets))}] → {retenus}"
        else:
            detail = f"{nombre}d{faces} [{', '.join(map(str, jets))}]"
        morceaux.append(("" if signe > 0 and not morceaux else ("+" if signe > 0 else "-")) + detail)
    return total, " ".join(morceaux).lstrip("+")


def critique(expression: str, detail: str):
    """Signale 20/1 naturel sur un d20 unique, cas où la règle change."""
    if not re.search(r"\b1?d20\b", expression.lower()):
        return None
    m = re.search(r"d20(?:k[hl]\d+)? \[([^\]]+)\](?: → \[([^\]]+)\])?", detail)
    if not m:
        return None
    retenus = m.group(2) or m.group(1)
    valeurs = [int(v.strip()) for v in retenus.split(",")]
    if len(valeurs) != 1:
        return None
    if valeurs[0] == 20:
        return "20 NATUREL"
    if valeurs[0] == 1:
        return "1 NATUREL"
    return None


def main():
    p = argparse.ArgumentParser(description="Lance des dés pour une partie de JDR.")
    p.add_argument("expression", nargs="?", help="ex. 1d20+5, 2d6+3, 4d6kh3")
    p.add_argument("--avantage", action="store_true", help="d20 en avantage (2d20kh1)")
    p.add_argument("--desavantage", action="store_true", help="d20 en désavantage (2d20kl1)")
    p.add_argument("--fois", type=int, default=1, help="répéter le jet N fois")
    p.add_argument("--etiquette", default="", help="ce que le jet représente")
    p.add_argument("--secret", action="store_true", help="marquer le jet comme caché au joueur")
    p.add_argument("--stats", action="store_true", help="génère 6 caractéristiques (4d6kh3)")
    p.add_argument("--journal", help="fichier où consigner le jet")
    a = p.parse_args()

    lignes = []

    if a.stats:
        valeurs = []
        for i in range(6):
            total, detail = evaluer("4d6kh3")
            valeurs.append(total)
            lignes.append(f"Caractéristique {i + 1} : {total}   ({detail})")
        lignes.append(f"→ Tableau : {sorted(valeurs, reverse=True)}   somme {sum(valeurs)}")
    else:
        if not a.expression:
            p.error("donne une expression (ex. 1d20+5) ou utilise --stats")
        expr = a.expression
        if a.avantage and a.desavantage:
            p.error("avantage et désavantage s'annulent : lance un d20 simple")
        if a.avantage or a.desavantage:
            garde = "kh1" if a.avantage else "kl1"
            expr = re.sub(r"^\s*\d*d20", f"2d20{garde}", expr, count=1, flags=re.IGNORECASE)
        for _ in range(max(1, a.fois)):
            try:
                total, detail = evaluer(expr)
            except ValueError as e:
                print(f"Erreur : {e}", file=sys.stderr)
                return 1
            marque = critique(expr, detail)
            ligne = f"{a.etiquette + ' : ' if a.etiquette else ''}{total}   ({detail})"
            if marque:
                ligne += f"   ⟵ {marque}"
            if a.secret:
                ligne = "[SECRET] " + ligne
            lignes.append(ligne)

    sortie = "\n".join(lignes)
    print(sortie)

    if a.journal:
        horo = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(a.journal, "a", encoding="utf-8") as f:
            for ligne in lignes:
                f.write(f"{horo}  {ligne}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
