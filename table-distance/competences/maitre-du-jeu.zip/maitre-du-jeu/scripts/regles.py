#!/usr/bin/env python3
"""Consultation des tables de valeurs exactes pour la compétence maitre-du-jeu.

Une table de règles récitée de mémoire finit toujours par être fausse — trois
erreurs silencieuses en une seule séance l'ont prouvé. Ce script est l'unique
voie d'accès aux valeurs chiffrées : il lit les fichiers de `donnees/`, qui ont
été collectés puis contre-vérifiés contre le SRD 5.1 (et, pour les seuils de
rencontre, contre les règles de base publiées, hors SRD).

Usage :
    python3 regles.py niveau 14                 # XP cumulés, bonus de maîtrise
    python3 regles.py sorts complet 18          # emplacements par niveau de sort
    python3 regles.py sorts demi 7
    python3 regles.py sorts occultiste 5
    python3 regles.py rencontre 4 --pj 1        # seuils d'XP + multiplicateurs
    python3 regles.py fp 3                      # XP rapportés par un FP
    python3 regles.py bloc veteran              # bloc de statistiques exact
    python3 regles.py bloc --liste
    python3 regles.py srd                       # périmètre exact du SRD 5.1
    python3 regles.py table xp|sorts|rencontres # tables complètes
"""

import argparse
import json
import sys
from pathlib import Path

DONNEES = Path(__file__).resolve().parent.parent / "donnees"

ALIAS_BLOCS = {
    "roturier": "commoner", "noble": "noble", "garde": "guard", "bandit": "bandit",
    "capitaine-bandit": "bandit-captain", "capitaine": "bandit-captain",
    "malfrat": "thug", "sectateur": "cultist", "cultiste": "cultist",
    "fanatique": "cult-fanatic", "acolyte": "acolyte", "pretre": "priest",
    "prêtre": "priest", "eclaireur": "scout", "éclaireur": "scout", "espion": "spy",
    "veteran": "veteran", "vétéran": "veteran", "chevalier": "knight", "mage": "mage",
    "assassin": "assassin", "gobelin": "goblin", "loup": "wolf",
    "squelette": "skeleton", "zombi": "zombie", "zombie": "zombie", "ogre": "ogre",
}

NOMS_FR = {
    "commoner": "Roturier", "noble": "Noble", "guard": "Garde", "bandit": "Bandit",
    "bandit-captain": "Capitaine bandit", "thug": "Malfrat", "cultist": "Sectateur",
    "cult-fanatic": "Fanatique de secte", "acolyte": "Acolyte", "priest": "Prêtre",
    "scout": "Éclaireur", "spy": "Espion", "veteran": "Vétéran",
    "knight": "Chevalier", "mage": "Mage", "assassin": "Assassin",
    "goblin": "Gobelin", "wolf": "Loup", "skeleton": "Squelette",
    "zombie": "Zombi", "ogre": "Ogre",
}


def charger(nom):
    chemin = DONNEES / f"{nom}.json"
    if not chemin.exists():
        sys.exit(f"Erreur : {chemin} introuvable. La compétence est incomplète — "
                 "ne cite aucune valeur de mémoire, signale le problème au joueur.")
    with open(chemin, encoding="utf-8") as f:
        return json.load(f)


def cmd_niveau(a):
    d = charger("progression")
    n = str(a.n)
    if n not in d["niveaux"]:
        sys.exit(f"Erreur : niveau {a.n} inconnu (1–20).")
    e = d["niveaux"][n]
    print(f"Niveau {a.n} : {e['xp']:,} XP cumulés · bonus de maîtrise +{e['maitrise']}".replace(",", " "))


def _ligne_sorts(t):
    return " · ".join(f"niv.{i+1}: {v}" for i, v in enumerate(t) if v) or "aucun emplacement"


def cmd_sorts(a):
    d = charger("emplacements")
    n = str(a.n)
    if a.type in ("complet", "demi"):
        table = d[a.type]
        if n not in table:
            sys.exit(f"Erreur : niveau {a.n} inconnu (1–20).")
        etiquette = ("Lanceur complet (barde, clerc, druide, ensorceleur, magicien)"
                     if a.type == "complet" else "Demi-lanceur (paladin, rôdeur)")
        print(f"{etiquette}, niveau {a.n} : {_ligne_sorts(table[n])}")
    else:
        table = d["occultiste"]
        if n not in table:
            sys.exit(f"Erreur : niveau {a.n} inconnu (1–20).")
        e = table[n]
        print(f"Occultiste niveau {a.n} : {e['emplacements']} emplacement(s) de "
              f"niveau {e['niveau_emplacement']} (récupérés sur repos court) · "
              f"{e['sorts_connus']} sorts connus · {e['invocations']} invocation(s)")


def cmd_rencontre(a):
    d = charger("rencontres")
    n = str(a.n)
    if n not in d["seuils"]:
        sys.exit(f"Erreur : niveau {a.n} inconnu (1–20).")
    s = d["seuils"][n]
    pj = a.pj
    print(f"Seuils d'XP, niveau {a.n}, {pj} PJ : "
          f"facile {s[0]*pj} · moyenne {s[1]*pj} · difficile {s[2]*pj} · mortelle {s[3]*pj}")
    print("Multiplicateur selon le nombre de monstres : "
          + " · ".join(f"{m['nombre']} → ×{m['mult']:g}" for m in d["multiplicateurs"]))
    if pj < 3 and d.get("ajustement_taille_groupe"):
        print(f"ATTENTION ({pj} PJ) : {d['ajustement_taille_groupe']}")
    print("(Le total d'XP des monstres, multiplié, se compare aux seuils. "
          "Source : règles de base, hors SRD. En solo, traite « moyenne » comme déjà difficile.)")


def cmd_fp(a):
    d = charger("rencontres")
    fp = {"0.125": "1/8", "0.25": "1/4", "0.5": "1/2"}.get(a.fp, a.fp)
    if fp not in d["fp_xp"]:
        sys.exit(f"Erreur : FP {a.fp} inconnu (0, 1/8, 1/4, 1/2, 1 à 30).")
    print(f"FP {fp} : {d['fp_xp'][fp]:,} XP".replace(",", " "))


def cmd_bloc(a):
    d = charger("blocs")
    blocs = d["blocs"]
    if a.liste or not a.nom:
        for slug in sorted(blocs, key=lambda s: NOMS_FR.get(s, s)):
            b = blocs[slug]
            print(f"{NOMS_FR.get(slug, slug):<20} ({slug:<15}) FP {b['fp']:>4} · CA {b['ca']} · PV {b['pv'].split(' ')[0]}")
        return
    slug = ALIAS_BLOCS.get(a.nom.lower(), a.nom.lower())
    if slug not in blocs:
        sys.exit(f"Erreur : bloc « {a.nom} » inconnu. Liste : python3 regles.py bloc --liste")
    b = blocs[slug]
    print(f"=== {NOMS_FR.get(slug, slug)} — FP {b['fp']} ({b['xp']} XP) ===")
    print(f"CA {b['ca']} · PV {b['pv']} · Vitesse {b['vitesse']}")
    noms = ["For", "Dex", "Con", "Int", "Sag", "Cha"]
    print(" · ".join(f"{c} {v} ({(v - 10) // 2:+d})" for c, v in zip(noms, b["stats"])))
    for cle, etiquette in (("sauvegardes", "Sauvegardes"), ("competences", "Compétences"),
                           ("immunites_resistances", "Immunités/résistances"), ("sens", "Sens")):
        if b.get(cle):
            print(f"{etiquette} : {b[cle]}")
    for t in b.get("traits", []):
        print(f"• {t['nom']} — {t['resume']}")
    for ac in b.get("actions", []):
        print(f"→ {ac['nom']} — {ac['resume']}")
    for r in b.get("reactions", []):
        print(f"↩ {r['nom']} — {r['resume']}")


def cmd_srd(a):
    d = charger("perimetre-srd")
    print("Périmètre du SRD 5.1 — ce qui y figure, et rien d'autre :")
    print("\nSous-classes (UNE par classe) :")
    for classe, sc in d["sous_classes"].items():
        print(f"  {classe} → {sc}")
    print("\nRaces et sous-races :")
    for race, sr in d["especes"].items():
        print(f"  {race}" + (f" ({', '.join(sr)})" if sr else ""))
    print(f"\nHistoriques : {', '.join(d['historiques'])} — c'est tout.")
    print(f"Dons : {', '.join(d['dons'])} — c'est tout.")
    if d.get("notes"):
        print(f"\n{d['notes']}")


def cmd_table(a):
    if a.quoi == "xp":
        d = charger("progression")
        for n in range(1, 21):
            e = d["niveaux"][str(n)]
            print(f"niveau {n:>2} : {e['xp']:>7,} XP · maîtrise +{e['maitrise']}".replace(",", " "))
    elif a.quoi == "sorts":
        d = charger("emplacements")
        for genre in ("complet", "demi"):
            print(f"--- {genre} ---")
            for n in range(1, 21):
                print(f"niveau {n:>2} : {_ligne_sorts(d[genre][str(n)])}")
        print("--- occultiste ---")
        for n in range(1, 21):
            e = d["occultiste"][str(n)]
            print(f"niveau {n:>2} : {e['emplacements']} × niv.{e['niveau_emplacement']} · "
                  f"{e['sorts_connus']} sorts connus · {e['invocations']} invocations")
    else:
        d = charger("rencontres")
        print("Seuils par PJ (facile/moyenne/difficile/mortelle) :")
        for n in range(1, 21):
            s = d["seuils"][str(n)]
            print(f"niveau {n:>2} : {s[0]} / {s[1]} / {s[2]} / {s[3]}")
        print("Multiplicateurs : " + " · ".join(f"{m['nombre']} → ×{m['mult']:g}" for m in d["multiplicateurs"]))
        print("FP → XP : " + " · ".join(f"{k}: {v}" for k, v in d["fp_xp"].items()))


def main():
    p = argparse.ArgumentParser(description="Tables de valeurs exactes (SRD 5.1 + règles de base).")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("niveau", help="XP cumulés et bonus de maîtrise")
    s.add_argument("n", type=int)
    s.set_defaults(f=cmd_niveau)

    s = sub.add_parser("sorts", help="emplacements de sorts")
    s.add_argument("type", choices=["complet", "demi", "occultiste"])
    s.add_argument("n", type=int)
    s.set_defaults(f=cmd_sorts)

    s = sub.add_parser("rencontre", help="seuils d'XP et multiplicateurs")
    s.add_argument("n", type=int, help="niveau des PJ")
    s.add_argument("--pj", type=int, default=1, help="nombre de personnages joueurs")
    s.set_defaults(f=cmd_rencontre)

    s = sub.add_parser("fp", help="XP rapportés par un facteur de puissance")
    s.add_argument("fp")
    s.set_defaults(f=cmd_fp)

    s = sub.add_parser("bloc", help="bloc de statistiques exact")
    s.add_argument("nom", nargs="?")
    s.add_argument("--liste", action="store_true")
    s.set_defaults(f=cmd_bloc)

    s = sub.add_parser("srd", help="périmètre exact du SRD 5.1")
    s.set_defaults(f=cmd_srd)

    s = sub.add_parser("table", help="tables complètes")
    s.add_argument("quoi", choices=["xp", "sorts", "rencontres"])
    s.set_defaults(f=cmd_table)

    a = p.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()
