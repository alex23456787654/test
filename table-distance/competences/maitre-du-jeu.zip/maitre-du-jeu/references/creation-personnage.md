# Création de personnage et progression

## Principe de conduite

Ne demande pas au joueur de remplir un formulaire. Pose-lui une question ouverte —
« qui est ce personnage, en une phrase ? » — puis traduis sa réponse en choix mécaniques
que tu lui soumets. Un joueur qui dit « une vieille ferronnière qui a fui sa cité »
attend que tu lui proposes naine, guerrière ou artisane, pas que tu lui récites la liste
des races du SRD.

Fais-lui valider chaque étape en une ligne, puis enchaîne. Vise dix minutes, pas une heure.

## Étapes

### 1. Concept
Une phrase : qui, d'où, et quel problème non résolu. Le problème non résolu est ce qui te
donnera des accroches de scénario plus tard — note-le dans `etat.md`.

### 2. Espèce
SRD 5.1 : humain, nain (des collines), elfe (haut elfe, elfe des bois, drow), halfelin
(pied-léger, robuste), demi-elfe, demi-orc, gnome (des roches), drakéide, tieffelin.
Retiens surtout : bonus de caractéristiques, vitesse, vision dans le noir, traits notables.

### 3. Classe
SRD 5.1 : barbare, barde, clerc, druide, ensorceleur, guerrier, magicien, moine,
occultiste, paladin, rôdeur, roublard. Fixe le dé de vie, les jets de sauvegarde maîtrisés,
les compétences au choix, et la sous-classe si elle arrive au niveau 1 (clerc, ensorceleur,
occultiste) ou plus tard.

**Attention au périmètre.** Le SRD 5.1 ne contient qu'**une seule sous-classe par
classe** — et un seul historique, et un seul don. Avant d'annoncer qu'une option est
« dans les règles », vérifie : `python3 scripts/regles.py srd`. Si le joueur veut une
option hors SRD (un patron Archifée, un collège de barde absent), accorde-la comme
arbitrage de table : mécanique calquée sur l'option SRD la plus proche, et la décision
consignée dans `etat.md` — c'est exactement ce pour quoi la section « Arbitrages de
table » existe.

### 4. Caractéristiques
Trois méthodes, propose-les :
- **Répartition fixe** : 15, 14, 13, 12, 10, 8 — équilibrée, recommandée par défaut.
- **Achat de points** : 27 points, scores de 8 à 15 avant modificateurs.
- **Tirage** : `python3 scripts/des.py --stats`. Plus vivant, plus inégal. Si la somme
  est catastrophique (< 65), propose de relancer le tableau entier.

Modificateur = (score − 10) ÷ 2, arrondi à l'inférieur.

### 5. Historique
Deux compétences, des outils ou langues, un équipement de départ, et surtout un lien avec
le monde. Invente-le avec le joueur plutôt que de piocher dans une liste : ce lien doit
pointer vers un lieu ou une personne que tu pourras faire intervenir.

### 6. Chiffres dérivés
- **PV niveau 1** = maximum du dé de vie + modificateur de Constitution
- **Bonus de maîtrise** : `python3 scripts/regles.py niveau <n>` — ne le récite pas
- **CA** = 10 + Dex, modifiée par l'armure portée
- **Initiative** = modificateur de Dextérité
- **DD des sauvegardes imposées** = 8 + bonus de maîtrise + modificateur de la
  caractéristique d'incantation

### 7. Équipement
Prends le paquet de départ de la classe plutôt que d'acheter pièce par pièce, sauf si le
joueur y tient. Note tout dans la fiche, y compris les rations et les torches : leur
épuisement crée des décisions.

## Le personnage apporte un récit au monde

Dans un univers partagé (`univers-partage.md`), chaque création de personnage se termine par une
question, posée simplement : **« Qu'est-ce qu'on raconte, chez toi, que les autres ne savent pas ? »**
— une légende de son village, ce que sa mère disait des étoiles, un dicton, une chanson de son
métier. Trois ou quatre phrases suffisent ; le joueur peut aussi la déposer plus tard dans
l'onglet « Créer » du menu du monde.

Ce récit entre dans `univers/mythes.md` comme **fragment**, daté, avec le personnage pour source.
Son statut réel (vrai, déformé, faux, blanc qu'il vient de remplir) se décide côté MJ dans
`mj/cosmogonie.md` — et le joueur ne le saura qu'en jouant. Ne corrige pas la légende pour qu'elle
colle aux vérités : un récit a le droit d'être faux, et c'est souvent là qu'une aventure commence.

## Montée de niveau

À l'annonce du niveau supérieur :
1. PV : jet du dé de vie + Con, ou valeur fixe moyenne (au choix du joueur, à conserver
   pour toute la campagne).
2. Nouvelles aptitudes de classe et de sous-classe.
3. Emplacements de sorts : `python3 scripts/regles.py sorts <complet|demi|occultiste> <niveau>`
   (le fonctionnement est dans `magie.md`, les nombres dans `donnees/`).
4. Bonus de maîtrise : `python3 scripts/regles.py niveau <n>`.
5. Aux niveaux 4, 8, 12, 16, 19 : +2 à une caractéristique, ou +1 à deux, ou un don.

Fais-le hors combat, note la date en jeu, et demande au joueur ce que son personnage a
appris depuis la dernière fois — cela transforme un ajustement comptable en scène.

## Seuils d'expérience (si tu joues à l'XP)

La table des XP cumulés par niveau ne se récite pas — elle a déjà été fausse une fois,
silencieusement : `python3 scripts/regles.py niveau <n>`, ou `regles.py table xp` pour
la table entière.

Alternative plus simple en solo : montée de niveau à la fin de chaque grand chapitre.
Annonce le mode retenu en session zéro et n'en change pas en cours de route.
