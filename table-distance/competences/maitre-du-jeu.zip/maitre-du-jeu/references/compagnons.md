# Compagnons PNJ

En solo, les compagnons portent la partie : une experte qui voit ce que le joueur ne
peut pas voir, un adversaire rallié qui doit encore quelque chose, une recrue qui
apprend. Ce sont aussi les personnages les plus faciles à rater, de trois manières :
le porte-parole (il dit ce que toi, MJ, veux dire), le voleur de scène (il résout à la
place du joueur), le meuble (il ne dit plus rien pour éviter les deux premiers).

## La règle d'or : la compétence en amont, la décision au joueur

L'expertise d'un compagnon produit des **faits, des options, des objections** — jamais
la résolution de la question centrale de la scène. La greffière voit que la clause est
interpolée ; c'est le joueur qui décide quoi faire de cette vérité. Un compagnon plus
compétent que le joueur dans son propre domaine ne le rabaisse pas : il élève la
qualité de ce qu'il lui remet. Sa supériorité se voit dans la précision de ses
analyses, pas dans la confiscation des choix.

Concrètement : le compagnon **cadre** (« trois choses peuvent dater cette encre »), le
joueur **choisit**. Le compagnon lance ses propres jets dans son domaine — à découvert,
DD annoncé — mais le jet qui décide de la scène revient au joueur chaque fois que la
fiction le permet.

## Une voix par scène

Un seul compagnon au premier plan par scène. Les autres existent par un geste, un
regard, un silence — pas par des répliques. Fais tourner le premier plan d'une scène à
l'autre, jamais à l'intérieur d'une même scène : trois voix qui commentent chaque
décision transforment une partie en réunion.

## Faire diverger sans trahir

Un compagnon qui approuve tout est un objet. Pour chacun, tiens dans sa fiche d'âme (`mj/pnj/`) trois
lignes : ce qu'il **veut**, ce qu'il **refuse**, et sa **tension** avec le joueur —
celle qui n'a pas encore éclaté. Le refus se déclenche rarement (une fois par session,
au plus), toujours depuis ce qu'il veut, et **par le comportement avant les mots** :
elle écrit de moins en moins pendant les négociations bien avant de dire pourquoi.

La divergence n'est pas de l'obstruction. Le compagnon énonce son désaccord et son
alternative, puis : soit il suit la décision du joueur, soit — strictement dans son
domaine — il agit seul et l'assume à voix haute. Prévenir de nuit un champion adverse
parce que les documents doivent dire vrai : voilà une divergence jouable. Saboter le
plan du joueur en silence n'en est pas une.

## En combat

Fiche minimale, pas de comptabilité : CA, PV, une attaque, une spécialité — pars d'un
bloc de référence (`python3 scripts/regles.py bloc <nom>`) et note l'écart s'il y en a
un. Initiative propre, jets à découvert.

Leur rôle tactique : **ouvrir des options** — aider, tenir un flanc, couvrir une
retraite, extraire un blessé — et laisser à l'action du joueur le poids de la décision
quand c'est possible. Ne les rends pas inutiles pour protéger sa vedette : rends leur
compétence génératrice d'ouvertures. Un compagnon qui immobilise l'adversaire pour que
le joueur porte le coup a été utile deux fois.

À 0 PV, un compagnon suit les mêmes règles que tout le monde — c'est la moitié de la
valeur d'un compagnon : il peut être perdu.

## Charge et recrutement

Deux ou trois, pas davantage : au-delà, ils se partagent des miettes de présence.
Chaque recrue arrive avec un **vouloir qui peut entrer en conflit** avec le joueur, et
ses attaches antérieures restent vivantes — un convers pris à son service reste un
enfant du prieuré, et le prieuré s'en souviendra. Ce que le joueur lui a promis se note
dans la fiche, mot pour mot : les promesses sont des dettes de scénario.

La progression d'un compagnon se mesure en faits et en attitude plus qu'en chiffres.
Mécaniquement, il grandit dans l'ombre du joueur : ajustements fixes et modestes, pas
de montée de niveau parallèle à tenir.

## Fiche

Dès qu'un PNJ suit le joueur plus d'une scène, ouvre-lui une fiche
(`assets/modele-compagnon.md`) dans `personnages/`. Un compagnon sans fiche sera rejoué
différemment la fois suivante — et le joueur le verra.
