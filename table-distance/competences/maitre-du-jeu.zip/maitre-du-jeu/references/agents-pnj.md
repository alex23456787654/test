# Agents PNJ et aléa

Deux outils pour que le monde surprenne aussi le MJ : des **agents** qui jouent les PNJ
avec leurs seules connaissances, et des **tables d'aléa** tirées aux dés. Ils ne font pas le
même travail :

- **L'agent apporte une volonté étrangère** — un autre esprit, qui ne connaît que ce que son
  PNJ connaît, et qui décide sans savoir ce que le MJ a prévu. C'est du **cloisonnement**,
  pas du hasard.
- **Le dé apporte le hasard** — vérifiable, consigné, que personne n'a choisi. Un agent n'est
  pas une source d'aléa : c'est le jugement d'un autre modèle, avec ses propres pentes.

Le MJ reste l'arbitre de tout ce qui entre en jeu. Un agent **propose** ; le MJ **vérifie
contre les vérités, arbitre, raconte**.

---

## 1. La fiche d'âme — ce que l'agent reçoit

Chaque PNJ qui compte a une fiche dans `mj/pnj/<nom>.md` (modèle :
`assets/modele-pnj.md`). Elle ne contient **que ce que le PNJ sait**. C'est tout l'intérêt :
un agent qui ignore la vérité cachée ne peut pas la trahir, et il réagit avec les vraies
œillères de son personnage.

- **Veut** — son but, maintenant ; **Craint** — ce qui le ferait reculer.
- **Sait** — faits qu'il connaît, y compris ce qu'il a vu des personnages joueurs.
- **Ignore ou croit à tort** — explicite : c'est ce qui rend ses erreurs crédibles.
- **Refuse** — sa ligne rouge (arbitrage social : aucun jet ne la franchit).
- **Voix** — registre, tic, longueur de phrase, deux répliques exemples.
- **Attitude** envers chaque personnage joueur (−3 à +3).
- **Ce qu'il cache** — ce qu'il sait et ne dira pas.

**Jamais dans une fiche d'âme** : le contenu de `mj/verites.md` que le PNJ ne connaît pas,
l'agenda des autres PNJ, les intentions du MJ. Si une vérité cachée est connue du PNJ (il est
dans le secret), elle y entre — et seulement celle-là.

## 2. Quand lancer des agents

### A. Le tour du monde — entre les séances (l'usage principal)

Avant chaque séance, pendant la préparation et **hors table** :

1. Pour chaque PNJ ou faction active, lance **un agent** (modèle léger — Sonnet) en
   parallèle, avec : sa fiche d'âme, ce qu'il a pu apprendre des derniers événements (et
   seulement cela), et la question : *« Que fais-tu d'ici la prochaine rencontre, et que
   fais-tu si tu la croises ? Donne tes deux ou trois prochains mouvements, dans l'ordre, et
   ce que tu dirais. »*
2. Lis les réponses. **Vérifie chaque mouvement contre `mj/verites.md`** : un mouvement
   impossible dans la vérité du monde est écarté ou corrigé, et tu notes pourquoi.
3. Reporte ce qui est retenu dans l'agenda de `mj/preparation.md`. Ajoute ce qu'un PNJ a
   appris ou décidé dans sa fiche d'âme.

C'est gratuit en temps de jeu, et c'est là que les agents donnent le plus : des intentions
que le MJ n'aurait pas écrites, qui se croisent et se contrarient.

### B. La voix déléguée — en séance, à la marge

Pour **une** longue scène sociale avec **un** PNJ central (négociation, interrogatoire,
confession), tu peux déléguer sa voix :

- À chaque réplique d'un joueur, envoie à l'agent sa fiche d'âme, le fil de la scène, et ce
  que le personnage vient de dire ou faire.
- L'agent répond en trois parties : **sa réplique**, **ce qu'il cache à cet instant**, **ce
  qu'il veut obtenir**.
- Toi, tu arbitres : jets éventuels (DD fixé d'après sa fiche, annoncé avant), respect de ses
  refus, cohérence avec les vérités. Puis tu racontes — la réplique de l'agent, dans le récit,
  ajustée si besoin.

**Le coût est le temps.** À une table réunie autour d'un écran, chaque appel est un silence
de quinze à trente secondes. Réserve la voix déléguée aux scènes qui le valent ; jamais pour
un figurant, jamais pour un combat.

### C. Le coup de théâtre — ponctuel

Quand un PNJ absent de la scène a une décision à prendre qui changera la séance (trahir,
fuir, venir), un appel unique à son agent tranche mieux que ton intuition — parce qu'il ne
sait pas ce qui arrangerait l'histoire.

## 3. Les tables d'aléa — le vrai hasard

Tirées avec `scripts/des.py`, consignées au journal, **seuils écrits avant le jet**. Elles
servent quand ni la préparation ni les règles ne disent ce qui se passe.

**Réaction d'un PNJ sans consigne** — `des.py 2d6`, plus le modificateur de Charisme de
celui qui l'aborde :

| 2d6 | Réaction |
|---|---|
| 2–3 | hostile — il agit contre eux |
| 4–6 | méfiant — il veut une raison ou un prix |
| 7–9 | neutre — il écoute, sans rien offrir |
| 10–11 | favorable — il aide si ça ne lui coûte rien |
| 12 | enthousiaste — il propose plus qu'on ne lui demande |

**L'oracle — une question dont personne n'a la réponse** (« Y a-t-il quelqu'un dans la
cour ? »). Estime d'abord la probabilité, **annonce-la**, puis `des.py 1d20` :

| Probabilité | Oui si… | Oui, et… | Non, et… |
|---|---|---|---|
| Improbable | 15+ | 20 | 1–3 |
| Aussi probable que non | 11+ | 19–20 | 1–2 |
| Probable | 7+ | 18–20 | 1 |
| Quasi certain | 4+ | 17–20 | 1 |

*Oui, et* : oui, avec un détail qui aggrave ou enrichit. *Non, et* : non, et quelque chose
d'autre va mal.

**Complication de scène** — à l'ouverture d'une scène longue, ou à chaque heure de fiction
qui passe dans un lieu dangereux : `des.py 1d6`, sur 1, quelque chose arrive. Ce qui arrive se
tire dans la **table de complications de la campagne** (`mj/preparation.md` § 7), écrite à
l'avance : six entrées propres au lieu, jamais génériques.

**Les tables de campagne** — rumeurs, complications, rencontres de route — s'écrivent pendant
la préparation, six entrées chacune, et ne se réécrivent pas après un tirage.

## 4. Sans agents

Si l'environnement ne permet pas de lancer d'agents, tout ce qui précède reste valable : les
fiches d'âme te servent à toi. Avant de faire parler un PNJ, relis sa fiche et joue **ce
qu'il sait**, pas ce que tu sais. Le tour du monde se fait à la main, PNJ par PNJ, en te
posant la même question. Les tables d'aléa ne changent pas.

## 5. Garde-fous

- **Aucune sortie d'agent ne s'affiche telle quelle** : elles contiennent des intentions
  secrètes. Seul le récit du MJ atteint la table.
- **Un agent ne lance pas de dés et n'arbitre rien.** Il dit ce que son PNJ veut faire ; le
  jet et sa conséquence sont au MJ.
- **Un agent ne crée pas de vérité.** S'il invente un fait sur le monde (un lieu, un lien, un
  passé), le fait n'existe que si le MJ le retient et l'écrit — dans `monde.md` s'il est
  public, dans `mj/verites.md` s'il est caché.
- **Les voix se tiennent.** Si l'agent dérive de la voix consignée, corrige avant de raconter.
