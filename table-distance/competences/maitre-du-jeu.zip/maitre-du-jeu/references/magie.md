# Magie

## Emplacements de sorts

Les nombres ne se récitent pas — la table a déjà été fausse une fois aux niveaux 17–20,
silencieusement :

```bash
python3 scripts/regles.py sorts complet 9      # barde, clerc, druide, ensorceleur, magicien
python3 scripts/regles.py sorts demi 7         # paladin, rôdeur
python3 scripts/regles.py sorts occultiste 5   # pact magic : emplacements, niveau, sorts connus
```

Ce qui se retient sans chiffres : le demi-lanceur commence ses sorts au niveau 2 et
plafonne au niveau 5 de sorts. L'occultiste a peu d'emplacements mais toujours au niveau
maximal, récupérés sur un **repos court** — ne l'oublie pas, c'est ce qui rend la classe
jouable.

Tenir le compte des emplacements dépensés est ta responsabilité autant que celle du
joueur : mets la fiche à jour à chaque incantation, sinon la ressource cesse d'exister.

## Caractéristique d'incantation

Intelligence : magicien. Sagesse : clerc, druide, rôdeur. Charisme : barde, ensorceleur,
occultiste, paladin.

- **DD de sauvegarde** = 8 + maîtrise + modificateur de caractéristique
- **Bonus d'attaque de sort** = maîtrise + modificateur

## Concentration

Un seul sort de concentration à la fois ; en lancer un second met fin au premier. La
concentration tombe si le lanceur est neutralisé, tué, ou s'il rate un jet de sauvegarde
de Constitution après avoir subi des dégâts : DD égal à 10 ou à la moitié des dégâts subis,
le plus élevé des deux.

Demande ce jet **à chaque fois** que le personnage encaisse un coup en concentrant. C'est
l'oubli le plus fréquent, et il change complètement l'équilibre des combats.

## Composantes

- **Verbale** : impossible si bâillonné ou dans une zone de silence.
- **Somatique** : nécessite une main libre.
- **Matérielle** : couverte par une bourse à composantes ou un focaliseur, sauf si le
  composant a un coût en pièces d'or ou est consommé — dans ce cas, il faut le posséder
  réellement. Ces exceptions sont des accroches d'aventure : utilise-les.

## Rituels

Certains sorts peuvent être lancés en rituel : 10 minutes de plus, aucun emplacement
dépensé. Accessible au barde, clerc, druide, magicien, occultiste selon leur pacte. Hors
combat, propose systématiquement l'option rituelle — le joueur oublie souvent qu'il l'a.

## Temps d'incantation

La plupart des sorts prennent une action. Règle importante : si le personnage lance un sort
en **action bonus**, il ne peut lancer, dans le même tour, qu'un tour de magie à action
comme autre sort.

Les sorts à incantation longue (1 minute et plus) sont ininterrompus ou perdus — parfaits
comme compte à rebours narratif : le joueur doit tenir la position pendant que ça monte.

## Contresort et dissipation

**Contresort** : réaction, à 18 m, annule automatiquement un sort de niveau 3 ou moins ;
au-delà, test de caractéristique d'incantation DD 10 + niveau du sort. Le lanceur doit
pouvoir voir l'incantation — donc décris toujours les gestes et les lueurs d'un
adversaire qui prépare un sort, sans quoi la réaction est impossible.

**Dissipation** : annule un effet magique en cours, automatiquement jusqu'au niveau de
l'emplacement utilisé, sinon test DD 10 + niveau du sort.

## Zones d'effet

Cône : la largeur égale la distance. Ligne : longue et étroite. Sphère et cylindre : rayon
depuis un point choisi. Une créature doit voir le point d'origine pour être affectée —
le couvert total protège même à l'intérieur de la zone.

En cas de doute sur le nombre de cibles touchées, tranche généreusement en faveur du joueur
et note ta décision : la cohérence de tes arbitrages compte plus que leur exactitude.

## Décrire la magie

Donne à chaque lanceur une signature. Un ensorceleur brûle, un magicien trace, un
occultiste emprunte. La même boule de feu ne doit pas ressembler à celle du PNJ d'en face.
Décris le coût visible : la sueur, l'odeur d'ozone, le silence qui suit.
