# Arbitrage social

Une partie entière peut se jouer sans un seul jet d'attaque — en procédure, en preuve et
en négociation. Le cadre du combat ne s'y transpose pas : au combat, un échec coûte des
PV et un tour ; dans une négociation, un jet raté qui ne produit « rien » tue la scène et
pousse le joueur à répéter la même phrase avec d'autres mots. Ce module donne au jeu
social ses équivalents de la CA, des PV et de l'initiative : des positions, une échelle
de DD, des horloges.

## Quand lancer les dés

Le triage habituel — automatique, impossible, incertain — s'applique, avec trois
précisions propres au social :

- **Un argument qui change les faits ne se lance pas.** Une preuve produite, une
  contradiction interne relevée, un précédent opposable : cela déplace le DD ou supprime
  le jet, et tu le dis (« ça, ce n'est plus à prouver »). Les dés jugent la manière et
  l'accueil, jamais la vérité.
- **C'est l'interlocuteur qui décide de l'impossible.** Ses refus (notés dans sa fiche d'âme, `mj/pnj/`)
  sont sa ligne rouge : aucun jet ne fera certifier à une greffière un acte dont elle
  doute. Réponds par ce qu'il faudrait changer pour que la demande devienne possible —
  c'est une accroche, pas un mur.
- **Un levier, un jet.** Le même argument répété n'est pas un nouveau jet. Un nouveau
  jet exige un levier nouveau : un fait, un témoin, une offre, un moment différent.

## L'échelle des DD

Fixe le DD d'après ce que la demande **coûte au PNJ**, pas d'après l'éloquence espérée :

| DD | La demande… |
|---|---|
| 10 | ne lui coûte rien : information publique, service minime, courtoisie |
| 15 | lui coûte quelque chose : un risque, de l'argent, sa réputation, une entorse à une consigne |
| 20 | trahit son camp ou son intérêt direct |
| 25 | contredit ce qu'il est — hors d'atteinte sans changer d'abord la situation |

Ajustements, dans cet ordre :

1. **Attitude** (−3 à +3, tenue dans `etat.md`) : à +2, un cran de moins ; à −2, un cran
   de plus ; à ±3, le DD 10 devient automatique ou le DD 20 devient impossible.
2. **Argument-fait** : une preuve ou un levier réel abaisse le coût réel de la demande —
   descends d'un cran (trahir son camp devient se protéger soi-même).
3. **Manière** : le moment choisi, l'appui d'un compagnon, une rhétorique qui touche ce
   que le PNJ veut ou craint donnent l'**avantage**. La manière ne déplace jamais le DD :
   elle joue sur le jet.

Et comme partout : annonce le DD avant de lancer, jamais après.

## Un échec coûte une position, pas un tour

Un jet social raté ne signifie jamais « rien ne se passe ». La scène bouge, mais contre
le joueur. Choisis un coût et énonce-le :

- l'attitude du PNJ descend d'un cran ;
- le prix monte : ce qui s'obtenait par la parole exige maintenant une garantie ;
- un tiers entre dans la scène — témoin, supérieur, foule ;
- une horloge avance : le temps perdu est un coût visible ;
- le levier est brûlé : cet argument-là ne sera plus reçu ;
- ce que le joueur a tenté se sait — et quelqu'un en tirera parti.

**Échec de justesse** (un ou deux points sous le DD) : accorde, mais avec un prix
immédiat. Une foule qui se scinde en deux moitiés — l'une qui s'inscrit, l'autre qui
marche vers le portail — vaut mieux qu'une foule qui « n'est pas convaincue ».

## Récompenser l'argumentation

Trois registres, trois réponses — et dis à chaque fois lequel tu appliques :

- **L'argument-fait** (preuve, précédent, contradiction) déplace le DD ou supprime le
  jet. C'est la récompense la plus forte : le joueur a changé la situation, pas le tirage.
- **L'argument-manière** (bien amené, au bon moment, à la bonne personne) donne
  l'avantage.
- **L'Inspiration** récompense l'argument que tu n'avais pas prévu et qui recadre la
  scène entière. Une fois par scène au plus, accordée à l'instant même, avec la raison
  dite à voix haute. À mesure que le joueur apprend à te surprendre, relève la barre :
  l'Inspiration paie l'invention, pas la routine.

## Le PNJ qui concède

Le moment le plus délicat d'une négociation : un PNJ qui s'effondre au premier point
perdu est un décor, un PNJ qui ne cède jamais est un mur. La règle : **on concède le
point, pas la cause.**

Avant une négociation qui compte, note les **positions** du PNJ — deux ou trois lignes
de défense, pas plus, dérivées de ce qu'il veut et de ce qu'il refuse. C'est le même
contrat que pour un lieu improvisé : décidé avant l'action, opposable ensuite. Quand une
position tombe, il recule d'un cran au lieu de céder :

1. **Conteste la portée** — « C'est vrai. Et alors ? »
2. **Déplace** — « Ce n'est pas à moi d'en juger » : une autorité, une procédure, un tiers.
3. **Met un prix** — « Admettons. Qu'est-ce que j'y gagne ? »
4. **Concède à moitié** — partiel, daté, conditionnel.

Quand la dernière position tombe, il cède — et tu lui donnes une phrase pour sauver la
face. La manière dont il la sauve décide de ce que tu viens de créer : un allié ou un
ennemi. Et pas de rétroactivité : tu n'inventes pas une position nouvelle parce qu'il
perd trop vite — ce serait remonter les PV d'un monstre en plein combat.

## Comptes à rebours non violents

Une signature à obtenir avant la nuit, une foule qui bascule en quarante secondes : la
tension vient du temps, pas des armes. Structure :

1. **Annonce l'horloge dans la fiction** — quarante secondes, trois coups de cloche,
   la bougie qui brûle — et convertis-la en **échanges** : une action résolue ou une
   tirade tenue = un cran.
2. **Décompte à voix haute** après chaque échange. Une horloge visible fait plus de
   tension que dix descriptions inquiétantes — celle-ci est la plus visible de toutes.
3. **Le monde bouge à chaque cran** : les PNJ avancent leurs propres actions, la foule
   fait dix pas, la porte se rapproche. Un cran sans conséquence est un cran perdu.

**Une foule est un PNJ** : une attitude unique, un meneur. C'est le meneur qu'il faut
prendre, ou personne — un jet contre « la foule » sans cible nommée n'a pas de prise.
Si la foule se scinde, chaque moitié devient un PNJ avec son meneur et son attitude.

## Jets secrets à seuils consignés

Pour tout jet secret dont l'interprétation n'est pas binaire — une réaction, un accueil,
un revirement — consigne les seuils **avant** de tirer, dans le journal :

```bash
echo "SEUILS ANNONCÉS AVANT JET — accueil de Guiral : 1-5 elle ne revient pas ; 6-10 il rejette et durcit ; 11-15 il croit et vient quand même ; 16-20 il croit et refuse le combat" >> campagnes/<nom>/jets.log
python3 scripts/des.py 1d20 --secret --etiquette "Accueil de Guiral" --journal campagnes/<nom>/jets.log
```

Le joueur pourra relire après coup que l'interprétation précédait le tirage, et non
l'inverse. C'est ce qui autorise un MJ artificiel à jouer des retournements durs : ils
sont vérifiables.
