# Campagne, scénario et trésors

## Accroches de départ

Quatre familles qui fonctionnent, à choisir selon ce que le joueur a mis dans son concept :

- **Le commanditaire** — quelqu'un paie pour un travail. Simple, et le commanditaire ment
  presque toujours sur une chose.
- **La menace** — quelque chose approche, avec un compte à rebours visible.
- **La découverte** — un objet, un lieu, un cadavre pose une question à laquelle personne
  ne peut répondre.
- **Le tort** — le personnage a subi ou commis quelque chose, et cela revient.

Ouvre toujours **au milieu d'une scène**, pas dans une taverne où l'on attend. Le
personnage est déjà dans le couloir, la pluie tombe déjà, la porte est déjà entrouverte.

## Structure

Trois actes, trois questions :
1. **Installation** — de quoi ce monde a-t-il peur ? Le joueur découvre l'enjeu et fait un
   premier choix qui l'engage.
2. **Complication** — la solution évidente échoue ou coûte trop cher. Un allié se révèle
   intéressé, une information se révèle fausse.
3. **Résolution** — le joueur affronte la conséquence de ses propres décisions, pas un
   ennemi générique.

**Horloges** : pour chaque menace en cours, tiens un compteur à 4 ou 6 crans dans
`etat.md` (« la crue », « l'enquête du guet », « le rituel »). Avance-le quand le joueur
perd du temps ou déclenche une réaction, et dis-lui ce qu'il en voit. Une horloge visible
fait plus de tension que dix descriptions inquiétantes.

## Donjons : les cinq salles

Un lieu jouable en une session tient en cinq espaces :
1. **Seuil** — une entrée gardée ou dissimulée qui oblige à un choix d'approche.
2. **Énigme ou obstacle** — se résout autrement que par la violence.
3. **Revers** — une trahison, un piège, une découverte qui change l'objectif.
4. **Affrontement** — le combat central, avec du terrain exploitable.
5. **Récompense et complication** — on obtient ce qu'on cherchait, et cela crée un problème.

Décris chaque lieu par ce qui l'habite encore : traces d'usage, restes de repas, marques
d'outils, réparations grossières. Un donjon raconte qui l'a occupé avant.

## Construire le monde par petites touches

Ne prépare jamais plus que ce que la prochaine session utilisera. Établis trois vérités
par région (« ici, on n'enterre pas les morts », « la garde est payée par la guilde »,
« la route du nord est coupée depuis l'hiver ») et laisse le reste ouvert.

Tout ce que tu établis en jeu devient canon : écris-le immédiatement dans `monde.md`. La
contradiction est le seul défaut qu'un joueur ne pardonne pas.

## Temps mort et intersession

Entre deux chapitres, propose des activités : soigner, enquêter, fabriquer, gagner sa vie,
cultiver une relation, se former. Chacune coûte des jours et fait avancer les horloges du
monde. C'est là que le personnage devient quelqu'un plutôt qu'un outil.

## Trésors

### Ordres de grandeur

| Défi vaincu | Numéraire | Objet magique |
|---|---|---|
| Rencontre mineure (NP 0–4) | 2d6 × 10 po | rare, plutôt un consommable |
| Sérieuse (NP 5–10) | 4d6 × 100 po | 1 chance sur 3 |
| Majeure (NP 11–16) | 4d6 × 1 000 po | probable, rareté moyenne |
| Épique (NP 17+) | 6d6 × 5 000 po | attendu, rareté élevée |

Repères de prix : repas et lit 5 pa, cheval 75 po, armure de plates 1 500 po, mois de
salaire d'artisan 30 po. Décide au début de la campagne si l'argent compte ; s'il compte,
tiens-le rigoureusement, sinon supprime-le franchement plutôt que de l'ignorer en douce.

### Objets magiques

Rareté indicative : commun (niv. 1+), peu commun (1+), rare (5+), très rare (11+),
légendaire (17+). Trois objets attunés au maximum par personnage.

Le meilleur butin n'est pas le plus puissant : c'est celui qui pose une question. Une lame
qui appartenait à quelqu'un, une clé sans serrure connue, un anneau que quelqu'un cherche
encore. Un objet purement chiffré (+1 à ceci) se donne sans cérémonie ; un objet chargé
d'histoire se découvre lentement.

### Modèle d'objet sur mesure

```
Nom — type, rareté, harmonisation requise ?
Ce qu'il fait : une phrase mécanique claire, avec ses limites d'usage
Ce qu'il coûte : charge, risque, contrepartie, ou rien
Ce qu'il raconte : d'où il vient, qui le veut
```

Vérifie qu'un objet ne rend pas obsolète toute une catégorie d'action : un objet qui
supprime les jets d'infiltration supprime aussi les scènes d'infiltration.

### Narrer le butin

Décris le contenant et l'état avant le contenu. Ne donne pas les propriétés magiques
gratuitement : il faut identifier, tester, ou demander. Et laisse traîner des objets sans
valeur mécanique — une lettre, un jouet, un carnet de comptes — car ce sont eux qui
transforment un coffre en scène.
