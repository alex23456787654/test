# Combat

## Ouvrir le combat

Ne bascule pas en mode combat sans le dire. Annonce clairement le passage à l'initiative,
et décris d'abord la disposition : qui est où, à quelle distance, ce qui sert de couvert,
et ce qui rend la scène particulière (un pont, un feu, un otage). Un combat sans terrain
n'est qu'un échange de chiffres.

**Initiative** : `python3 scripts/des.py 1d20+X --etiquette "Initiative <nom>"` pour chaque
camp. Groupe les créatures identiques sur une seule initiative pour aller plus vite.
Affiche l'ordre du tour et rappelle-le à chaque tour.

**Surprise** : compare la Discrétion des attaquants à la Perception passive des défenseurs
(10 + modificateur de Sagesse + maîtrise). Les surpris ne font rien au premier tour et ne
peuvent pas réagir.

## Économie d'action

À son tour, une créature dispose de :
- **un déplacement** (sa vitesse, fractionnable) ;
- **une action** : attaquer, lancer un sort, se désengager, esquiver, se cacher, foncer,
  aider, préparer, utiliser un objet, ou toute action improvisée que tu juges raisonnable ;
- **une action bonus** seulement si une aptitude la lui accorde ;
- **une réaction** par round, souvent une attaque d'opportunité.

Terrain difficile : chaque mètre parcouru en coûte deux. Se relever coûte la moitié de la
vitesse.

## Résoudre une attaque

1. Jet d'attaque : `1d20 + caractéristique + maîtrise` contre la CA de la cible.
2. Égal ou supérieur : touché. 20 naturel : critique, touche toujours. 1 naturel : raté.
3. Dégâts : dés de l'arme + modificateur. Sur un critique, double **les dés seulement**,
   pas le modificateur.
4. Narre le résultat en termes de fiction : où le coup porte, ce que la créature fait en
   retour, comment son état visible change.

**Avantage / désavantage** : `--avantage` ou `--desavantage`. Ils ne se cumulent jamais ;
une source de chaque s'annule. Attaquer une créature à terre en corps à corps donne
l'avantage, à distance le désavantage.

**Couvert** : à moitié +2 CA, aux trois quarts +5 CA, total = pas de ciblage direct.

**Attaque d'opportunité** : déclenchée en quittant l'allonge d'un ennemi, sauf action de
désengagement ou téléportation.

## Dégâts, inconscience, mort

- À 0 PV, un personnage joueur tombe inconscient et fait à son tour un **jet de sauvegarde
  contre la mort** : d20 sans modificateur, 10 ou plus = succès. Trois succès : stabilisé.
  Trois échecs : mort. 1 naturel compte double échec, 20 naturel : reprend 1 PV.
- Recevoir des dégâts alors qu'on est à 0 PV : un échec automatique, deux si l'attaque
  était un critique.
- **Dégâts massifs** : des dégâts égaux ou supérieurs au maximum de PV en un seul coup
  tuent net.
- Les monstres, eux, meurent simplement à 0 PV — sauf si le joueur annonce vouloir
  assommer plutôt que tuer, ce qui est toujours permis en corps à corps.

Lance les sauvegardes contre la mort à vue, jamais en secret : c'est le seul moment où la
tension doit être partagée intégralement.

## États principaux

| État | Effet essentiel |
|---|---|
| À terre | déplacement rampant, désavantage aux attaques, attaques en mêlée contre lui avantagées |
| Agrippé | vitesse 0, prend fin si l'agrippeur est neutralisé |
| Aveuglé | échoue aux jets liés à la vue, désavantage en attaque, avantage contre lui |
| Assourdi | échoue aux jets liés à l'ouïe |
| Charmé | ne peut attaquer le charmeur, qui a l'avantage aux interactions sociales |
| Effrayé | désavantage tant que la source est en vue, ne peut s'en approcher |
| Empoisonné | désavantage aux attaques et aux tests |
| Entravé | vitesse 0, désavantage en attaque et aux sauvegardes de Dex, avantage contre lui |
| Étourdi | incapable d'agir, échec auto aux sauvegardes de Force et Dex |
| Inconscient | à terre, incapable d'agir, coups en mêlée à moins de 1,5 m automatiquement critiques |
| Neutralisé | ni action ni réaction |
| Paralysé | comme étourdi, plus critiques automatiques en mêlée rapprochée |

## Dangers d'environnement

Chute : 1d6 par tranche de 3 m, maximum 20d6. Suffocation : Constitution en minutes de
réserve, puis 0 PV. Feu, acide, froid extrême : 1d6 à 4d6 par round selon l'intensité.
Utilise-les — un combat où le décor menace autant que l'ennemi vaut trois combats plats.

## Narration

Alterne les registres pour éviter la litanie « il attaque, il touche, il inflige » :
décris tantôt la manœuvre, tantôt la réaction de la cible, tantôt un détail du décor qui
change. Signale les PV des ennemis par des états visibles (« il tient encore debout mais
son bras gauche pend ») plutôt que par des chiffres, sauf si le joueur demande.

Quand un combat est joué d'avance — ennemis en déroute, issue certaine — coupe court et
narre la fin plutôt que de dérouler six rounds sans enjeu.
