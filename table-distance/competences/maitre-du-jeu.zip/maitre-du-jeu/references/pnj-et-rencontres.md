# PNJ et rencontres

## Improviser un PNJ en dix secondes

Trois éléments suffisent, dans cet ordre : **ce qu'il veut**, **ce qui se voit**, **comment
il parle**. Le reste s'invente en jouant.

- *Veut* : être payé, être laissé tranquille, protéger quelqu'un, savoir ce qui s'est
  passé, ne pas être découvert, monter d'un cran.
- *Se voit* : une main abîmée, un vêtement trop beau pour l'endroit, un regard qui fuit,
  une odeur, un tic.
- *Parle* : trop vite, par questions, en formules toutes faites, en coupant, à voix basse.

Un PNJ mémorable a **une** particularité forte, pas quatre. Écris-la dans `table.md` (voix des PNJ) dès
qu'il a un nom, et ouvre sa fiche d'âme dans `mj/pnj/` s'il compte, sinon tu le rejoueras différemment la fois suivante — c'est le défaut le
plus visible d'un MJ artificiel.

## Statistiques rapides — et blocs exacts

Pour un PNJ sans importance mécanique, ne fais pas de fiche. Trois nombres suffisent :

| Type | CA | PV | Attaque |
|---|---|---|---|
| Roturier, serviteur | 10 | 4 | +2, 1d4 |
| Garde, bandit | 12–14 | 11–16 | +3, 1d6+1 |
| Vétéran, capitaine | 16–17 | 45–65 | +5, 2× 1d8+3 |
| Champion, chef de faction | 18 | 90–120 | +7, 3 attaques |

Modificateurs par défaut : +0 partout, +2 dans son domaine, +4 s'il est exceptionnel,
−1 s'il est diminué. Perception passive = 10 + modificateur de Sagesse.

Dès qu'un adversaire **compte** — il survivra à la scène, ou la scène dépend de lui —
prends un bloc exact au lieu d'improviser des chiffres :

```bash
python3 scripts/regles.py bloc --liste     # ~20 blocs SRD embarqués, du roturier à l'ogre
python3 scripts/regles.py bloc veteran
```

Un adversaire sur mesure se construit par écart déclaré à partir du bloc le plus proche
(« un vétéran, mais lent et sans arbalète ») — l'écart se note dans `etat.md` sous
« Arbitrages de table ».

## Doser une rencontre

Les seuils d'XP par niveau et les multiplicateurs par nombre de monstres ne se récitent
pas — c'est la table qui a été fausse deux fois, silencieusement :

```bash
python3 scripts/regles.py rencontre 4 --pj 1   # seuils au niveau 4 pour 1 PJ + multiplicateurs
python3 scripts/regles.py fp 3                 # XP rapportés par un monstre de FP 3
```

Le principe qui se retient sans chiffres : le budget se compare au total d'XP des
monstres **multiplié** selon leur nombre — le nombre compte plus que la somme des
puissances.

**En solo**, ces chiffres sont trompeurs. Un personnage seul n'a pas d'action de secours,
pas de soigneur et pas de relais : traite la ligne « moyenne » comme déjà difficile, et
compense en donnant des compagnons PNJ, du terrain exploitable ou une porte de sortie
visible avant que le combat ne commence.

## Philosophie des rencontres

Toutes les rencontres ne sont pas des combats, et tous les combats ne se gagnent pas en
tuant. Fixe pour chacune un **objectif** autre que « réduire les PV à zéro » : tenir trois
rounds, atteindre la porte, empêcher le rituel, capturer un chef vivant. Le combat devient
immédiatement plus tactique.

Fais fuir les ennemis. Une créature intelligente qui perd la moitié de ses PV et voit son
chef tomber ne se bat pas jusqu'à la mort — elle recule, prévient les autres, revient
mieux préparée. C'est aussi comme cela que se construisent les antagonistes récurrents.

Annonce le danger avant qu'il ne frappe : traces, bruits, cadavre, odeur. Un joueur tué
par une menace qu'il ne pouvait pas anticiper conclura que le monde est arbitraire, et il
aura raison.

## Factions

Deux ou trois suffisent au démarrage. Pour chacune : ce qu'elle veut, ce qu'elle possède,
ce qu'elle refuse de faire, et son opinion actuelle du personnage joueur (échelle de
−3 hostile à +3 allié, notée dans `etat.md`). Fais bouger cet indicateur après chaque
action notable — c'est ce qui rend le monde réactif sans travail supplémentaire.

Entre deux sessions, avance leurs plans d'un cran, indépendamment de ce que fait le joueur.
Note ce mouvement dans `etat.md` : c'est la différence entre un décor et un monde.

## Banques de noms

Rendre les noms cohérents par culture aide plus que leur beauté. Fixe deux ou trois
sonorités par région et tiens-t'y — par exemple, cité marchande en *-ane, -ora, -esse* ;
hautes terres en consonnes dures *Kragh, Dorn, Bral* ; clergé en noms composés
*Main-de-Cendre, Second-Vœu*. Note-les dans `monde.md`.
